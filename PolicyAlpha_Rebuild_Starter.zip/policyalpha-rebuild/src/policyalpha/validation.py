from dataclasses import dataclass


@dataclass(frozen=True)
class MetricSummary:
    metric_name: str
    value: float | None
    sample_count: int
    period: str
    baseline: str | None = None


def metric_is_reportable(m: MetricSummary) -> bool:
    return m.value is not None and m.sample_count > 0 and bool(m.period.strip())


def confidence_label(value: float | None, calibrated: bool) -> str:
    if value is None:
        return "Not available"
    if not 0 <= value <= 1:
        raise ValueError("confidence must be between 0 and 1")
    return f"{value:.0%} calibrated probability" if calibrated else f"{value * 100:.0f}/100 uncalibrated score"
