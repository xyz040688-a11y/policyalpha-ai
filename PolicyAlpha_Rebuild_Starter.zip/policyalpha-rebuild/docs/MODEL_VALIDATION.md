# Model validation, confidence and scoring

## Do not conflate

- Recommendation score: ranking score used to order candidates.
- Confidence: calibrated probability only when a calibration study supports it.
- Scenario interval: possible return/price range at a stated horizon.
- Portfolio score: transparent measure of portfolio fit to stated objective/risk constraints.
- Outcome score: post-horizon score awarded against recorded forecast and actual outcome.

A score of 90/100 is not automatically a 90% probability of success.

## Immutable forecast contract

At creation time store forecast ID, timestamp/timezone, instrument, exchange/currency, adjusted reference price, action, horizon, target/entry/exit ranges, probability distribution or quantiles where supportable, model/config version, feature snapshot, event IDs, sources/publication times, benchmark, thesis, risks, invalidation conditions and missing data.

Forecast records are append-only. A correction creates a superseding record with an audit reason; never silently edit the original.

## Horizons and benchmarks

Evaluate 1, 5, 20 and 60 trading sessions where relevant. Compare absolute return, NIFTY 50 relative return, sector relative return, directional correctness, target/interval coverage and calibration. Use adjusted prices and handle dividends, splits, symbol changes, suspensions and delistings.

## Metrics

Balanced accuracy; class-specific precision/recall; majority-class and simple momentum baselines; Brier score/skill; log loss; expected calibration error (ECE) with bin definitions and counts; ROC-AUC only where appropriate; Matthews correlation coefficient; interval coverage/width; benchmark-relative returns and drawdown.

Never report a metric without denominator, period, sample count, universe and provenance. Guard against class imbalance, repeated historical origins, look-ahead leakage and overlapping labels.

## Validation design

- Chronological walk-forward evaluation.
- Purge/embargo overlapping label windows.
- Sealed final test period not used for model selection.
- Per-symbol, sector, regime and aggregate reporting.
- Compare against simple baselines.
- State minimum sample requirements before interpreting cohort metrics.
- Historical replay is not prospective live evidence.
- Passing software tests is not proof of predictive accuracy.

## Learning policy

**No continuous learning.** No automatic retraining, automatic feature/weight mutation, self-promotion or unattended experiment schedule. Model changes are explicit, versioned code changes reviewed by a human. Historical evaluation runs only when manually requested against a fixed, identified dataset. Any future controlled retraining requires separate explicit approval and a reproducible validation plan.
