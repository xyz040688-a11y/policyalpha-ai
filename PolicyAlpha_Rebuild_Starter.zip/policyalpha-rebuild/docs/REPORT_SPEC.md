# PolicyAlpha report specification

One consolidated PDF, maximum five pages. No repeated reports in one run.

## Visual system
Dark navy/charcoal base, high-contrast text, restrained teal highlights. Green = positive/profit; red = negative/loss. Use cards, charts and sector ranking visuals. Never fabricate chart points or fill missing data with zero.

## Page 1 — Decision dashboard
Market regime and timestamp; verified portfolio value/P&L; scenario progress toward aspirational 30% annual objective; top actions; data freshness/coverage.

## Page 2 — Portfolio decisions
Holding cards with BUY/HOLD/SELL/WATCHLIST or retain/trim/exit assessment; portfolio fit score /100 and breakdown; exit-range alerts; material news; suggested changes with amount and reason (minimum ₹10,000).

## Page 3 — Best stock opportunities
Best ranked opportunities across independent events; decision, entry/exit, target, downside, horizon, expected return range and calibrated confidence; brief rationale and invalidation. Maximum three candidates per event, no forced stock per headline.

## Page 4 — Sector and macro intelligence
Top three sector opportunities with previous/current rank and expected direction; commodity, policy, global and currency transmission chains; cause, company exposure and counterarguments; separate facts from hypotheses.

## Page 5 — Prediction accountability and model health
Prior recommendations and movement since recommendation; matured tests showing AI prediction, actual outcome, correct/incorrect and score; aggregate metrics with sample sizes/baselines; missing/stale data and limitations.

Unavailable data must be shown as unavailable with reason if known. No placeholder BUY calls or invented metrics.
