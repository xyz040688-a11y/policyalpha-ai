# Data contracts

All source data preserves provenance and time semantics. Use UTC internally and retain original timezone.

## Common provenance
`source_name`, `source_record_id`, `source_url`, `published_at`, `observed_at`, `retrieved_at`, `as_of`, `quality_status`, `raw_payload_hash`.

## Event
`event_id`, `title`, `event_type`, `entities`, `geographies`, `published_at`, `first_seen_at`, `last_updated_at`, `source_ids`, `materiality`, `cause_classification`, `cause_evidence`, `counter_evidence`, `duplicate_cluster_id`.

Unknown values remain unknown, not silently inferred.

## Market observation
`instrument_id`, `timestamp`, OHLCV, `currency`, `adjustment_status`, `provider`, `quality_status`. Intraday reaction requires timestamped data at adequate frequency.

## Company exposure
`company_id`, `sector`, `business_segments`, `input_cost_exposure`, `revenue_exposure`, `customer_exposure`, `geographic_exposure`, `hedging_inventory_contracts`, `evidence_sources`, `as_of`. If company-level exposure is unavailable, label the inference as sector-level and lower its evidence grade.

## Forecast and outcome
Forecast: `forecast_id`, `created_at`, `instrument_id`, `action`, `horizon_sessions`, `reference_price`, `entry_range`, `target_range`, `risk_range`, `confidence`, `confidence_type`, `quantiles`, `thesis`, `event_ids`, `source_ids`, `model_version`, `feature_snapshot_id`, `benchmark_id`.

Outcome: `forecast_id`, `maturity_date`, `actual_price`, `actual_return`, `benchmark_return`, `sector_return`, `direction_correct`, `target_hit`, `risk_hit`, `data_quality_status`.

## Portfolio import
Each parsed holding includes `symbol`, `exchange`, `quantity`, `average_cost`, `market_value` if available, `currency`, `source_image_or_file`, `extraction_confidence`, `needs_user_confirmation`. Ambiguous rows are excluded until confirmed.
