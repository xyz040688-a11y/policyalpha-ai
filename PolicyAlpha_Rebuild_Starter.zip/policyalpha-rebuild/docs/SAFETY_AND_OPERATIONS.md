# Safety and operating rules

## Hard boundaries
1. Analysis and decision support only. Never submit, authorise or execute trades.
2. No broker credentials or order-routing APIs.
3. No continuous learning, self-modifying weights, scheduled retraining, background loops or uncontrolled polling.
4. No unattended daily schedule in the initial release.
5. Manual GitHub Actions only. No `schedule`, `push` or recurring triggers.
6. No secrets, portfolio screenshots or private holdings committed to Git.
7. Provider calls require explicit rate limits, caching, backoff and a cost budget.
8. Never bypass account restrictions, rate limits, access controls or platform enforcement. If GitHub restricts an account, stop and use official support/appeal channels.

## Secrets
Use environment variables locally and GitHub Actions secrets only after explicit configuration. `.env` and portfolio files are gitignored. Never print tokens in logs.

## Data governance
Respect provider terms and rate limits; keep source attribution; store minimum personal portfolio data; separate public market data from private portfolio records; provide deletion/export controls before persistent portfolio storage is enabled.

## Change control
Version every model/configuration. Keep changes in reviewable commits/PRs. Run deterministic offline tests manually. No automatic merge or model promotion. Record what changed, why and which tests ran.

## GitHub safety
Confirm linked GitHub identity before publishing. Do not create repeated repositories, mass commits, high-frequency workflows or repeated API calls. If repository creation is unavailable through the current integration, create one empty repository through GitHub's official UI and provide its URL for population.
