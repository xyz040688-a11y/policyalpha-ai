# Product requirements reconstructed from the supplied conversation

## Product identity and objective

PolicyAlpha is an investment decision-support and portfolio assessment model, not a research-paper generator and not an automated trading system. It may analyse and recommend; the user alone decides whether to transact.

- Coverage: Indian equities first, with global markets and cross-border events as context; architecture should extend to global equities.
- Portfolio objective: assess alignment with an aspirational 30% annual return objective. This is a scenario target, never a promise or guaranteed return.
- Portfolio changes: explain the suggested amount and rationale; the conversation specifies ₹10,000 as the minimum proposed change size.
- Accept a Groww portfolio screenshot at any time. Extract holdings but flag uncertain rows for confirmation; never silently add ambiguous symbols.

## Daily decision workflow

The conversation requested one consolidated daily decision report around 9:00 AM IST. For the safe initial rebuild, execution is manual only; no schedule is enabled. A daily schedule can be considered later only after explicit approval and provider/cost verification.

1. Ingest and deduplicate material news, government policy and corporate events.
2. Rank events by expected market relevance, not article count.
3. Preserve publication time and check relevant market movement immediately before/after publication; a 30-minute pre-event reaction check was explicitly requested.
4. Separate a price move from a verified explanation.
5. Trace direct and indirect sector/company transmission channels.
6. Synthesize multiple independent events. At most three stock candidates per event; do not force one stock per headline.
7. Analyse current holdings and the wider opportunity universe.
8. Produce concise decisions, not raw data dumps.
9. Generate one consolidated PDF of no more than five pages.

## Intelligence dimensions

- Domestic/global macro, government policy, schemes, regulation, tariffs and public spending.
- Commodities and input costs: metals, energy, agriculture and relevant industrial inputs.
- Currency, rates, freight, supply chains and demand.
- Event cause classification: supply expansion/disruption, demand expansion/contraction, inventory, currency, policy/tariff, fund flows and other causes.
- Company fundamentals, balance-sheet quality, cash flow and governance.
- Company-specific event exposure: input mix, sourcing, inventory, hedging, contracts, pricing power, order book and customer demand.
- Sector and peer-network analysis, including positive read-through from peers to better-positioned companies.
- Sector-aware valuation; no single valuation formula for every business.
- Market expectations/perception: compare improving/deteriorating fundamentals with what valuation and price behaviour imply is already expected.
- Technical/price action is one input, never the sole basis for a recommendation.

## Decisions and required output

Each stock decision should include when supportable:
- BUY, SELL, HOLD or WATCHLIST.
- Preferred entry range or exit/avoid range.
- Expected target and downside/risk range.
- Explicit horizon (short, medium or long term).
- Expected upside/downside range.
- Confidence and its evidence basis.
- 80%, 95% and 99% scenario/uncertainty ranges when statistically supportable.
- Main catalyst, why selected, event links, opposing evidence and invalidation conditions.
- What changed since the previous recommendation.
- For holdings: continue/trim/exit assessment and exit-range alert condition.

WATCHLIST is for insufficient or conflicting evidence, not the default. Never manufacture BUY/SELL calls or confidence. The conversation contains both an earlier >90% confidence preference and later dissatisfaction with everything becoming WATCHLIST. Reconstructed rule: confidence thresholds must be configurable; display calibrated probability only when calibration supports it, and otherwise label a score as uncalibrated.

## Portfolio

- Accept screenshot or structured holdings file.
- Extract symbol, quantity, average price and available values; flag uncertain extraction.
- Assess holdings against sector/macro outlook, fundamentals, valuation, risk and goal scenarios.
- Score portfolio fit /100 with a transparent breakdown.
- Suggest changes only with rationale, expected effect, amount (minimum ₹10,000) and risk.
- Track user-entered holdings and exit-range conditions.
- Keep raw P/E, EBITDA and other financial inputs internally; show decision-relevant conclusions only.

## Prediction accountability

Every recommendation is an immutable dated forecast. Later information must not overwrite what was known at forecast time. Evaluate after 1, 5, 20 and 60 trading sessions where relevant, compared with NIFTY 50 and sector benchmarks. Show exact test, AI prediction, actual outcome, correct/incorrect result, score awarded and aggregate metrics.
