from dataclasses import dataclass
from typing import Sequence


@dataclass(frozen=True)
class Event:
    event_id: str
    title: str
    published_at: str | None
    source_ids: tuple[str, ...]
    cause: str = "unknown"
    materiality: float | None = None


def deduplicate_events(events: Sequence[Event]) -> list[Event]:
    """Exact-title baseline; production clustering must use entities and time windows."""
    seen: set[str] = set()
    output: list[Event] = []
    for event in events:
        key = " ".join(event.title.casefold().split())
        if key and key not in seen:
            seen.add(key)
            output.append(event)
    return output


def candidates_per_event_limit(count: int) -> int:
    return max(0, min(count, 3))
