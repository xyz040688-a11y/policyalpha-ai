from dataclasses import dataclass
from .contracts import Action, ConfidenceType


@dataclass(frozen=True)
class DecisionEvidence:
    fundamental_score: float | None
    valuation_score: float | None
    event_score: float | None
    exposure_score: float | None
    market_expectation_score: float | None
    risk_score: float | None
    data_quality_ok: bool
    material_conflict: bool = False


@dataclass(frozen=True)
class Decision:
    action: Action
    rationale: str
    recommendation_score: float | None
    confidence: float | None
    confidence_type: ConfidenceType


def decide(e: DecisionEvidence) -> Decision:
    """Contract-level placeholder, not a production alpha model."""
    parts = [e.fundamental_score, e.valuation_score, e.event_score,
             e.exposure_score, e.market_expectation_score, e.risk_score]
    if not e.data_quality_ok or any(x is None for x in parts) or e.material_conflict:
        return Decision(Action.WATCHLIST, "Insufficient or conflicting evidence.",
                        None, None, ConfidenceType.NOT_AVAILABLE)
    score = sum(float(x) for x in parts) / len(parts)
    if score >= 70:
        action, reason = Action.BUY, "Positive evidence composite; validate price range and risk."
    elif score <= 30:
        action, reason = Action.SELL, "Negative evidence composite; validate holding context and exit range."
    elif score >= 45:
        action, reason = Action.HOLD, "Mixed-to-neutral evidence; maintain only if thesis remains intact."
    else:
        action, reason = Action.WATCHLIST, "Evidence does not yet support a directional decision."
    return Decision(action, reason, score, None, ConfidenceType.NOT_AVAILABLE)
