from dataclasses import dataclass


@dataclass(frozen=True)
class Holding:
    symbol: str
    quantity: float
    average_cost: float
    extraction_confidence: float = 1.0
    confirmed: bool = True


def assessable_holdings(holdings: list[Holding]) -> list[Holding]:
    return [h for h in holdings if h.confirmed and h.extraction_confidence >= 0.95
            and h.quantity > 0 and h.average_cost > 0]


def suggested_change_is_large_enough(amount_inr: float) -> bool:
    return amount_inr >= 10_000
