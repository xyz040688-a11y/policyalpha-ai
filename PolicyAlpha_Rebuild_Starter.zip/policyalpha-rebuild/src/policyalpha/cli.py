import argparse


def main():
    parser = argparse.ArgumentParser(description="PolicyAlpha manual tools")
    parser.add_argument("command", choices=["validate"])
    args = parser.parse_args()
    if args.command == "validate":
        from .contracts import Action, ConfidenceType, Forecast
        Forecast("contract-smoke-test", "NSE:DEMO", Action.WATCHLIST,
                 "2026-01-01T00:00:00Z", 5, 100.0,
                 "Contract validation only; not a market forecast.",
                 "scaffold-0.1.0", None, ConfidenceType.NOT_AVAILABLE)
        print("Contract validation passed. No market data fetched; no learning or trading performed.")


if __name__ == "__main__":
    main()
