import pytest
from policyalpha.contracts import Action, ConfidenceType, Forecast, PriceRange
from policyalpha.decision import DecisionEvidence, decide
from policyalpha.event_intelligence import Event, deduplicate_events, candidates_per_event_limit
from policyalpha.portfolio import Holding, assessable_holdings, suggested_change_is_large_enough
from policyalpha.validation import MetricSummary, metric_is_reportable, confidence_label


def test_invalid_confidence_rejected():
    with pytest.raises(ValueError):
        Forecast("f1", "NSE:X", Action.BUY, "2026-01-01T00:00:00Z", 5, 100, "x", "v1",
                 1.2, ConfidenceType.UNCALIBRATED_SCORE)


def test_calibrated_probability_requires_value():
    with pytest.raises(ValueError):
        Forecast("f1", "NSE:X", Action.BUY, "2026-01-01T00:00:00Z", 5, 100, "x", "v1",
                 None, ConfidenceType.CALIBRATED_PROBABILITY)


def test_invalid_price_range_rejected():
    with pytest.raises(ValueError):
        PriceRange(120, 100)


def test_missing_or_conflicting_evidence_means_watchlist():
    d = decide(DecisionEvidence(80, 80, None, 70, 60, 60, True))
    assert d.action == Action.WATCHLIST and d.confidence is None
    d2 = decide(DecisionEvidence(80, 80, 80, 80, 80, 80, True, True))
    assert d2.action == Action.WATCHLIST


def test_event_dedupe_and_candidate_limit():
    events = [Event("1", " Steel prices fall ", None, ("a",)),
              Event("2", "steel prices fall", None, ("b",))]
    assert len(deduplicate_events(events)) == 1
    assert candidates_per_event_limit(10) == 3


def test_ambiguous_screenshot_rows_excluded():
    rows = [Holding("TCS", 2, 3000, .99, True), Holding("UNKNOWN", 4, 100, .55, False)]
    assert [h.symbol for h in assessable_holdings(rows)] == ["TCS"]


def test_minimum_portfolio_change():
    assert not suggested_change_is_large_enough(9999)
    assert suggested_change_is_large_enough(10000)


def test_metrics_need_denominator_and_period():
    assert not metric_is_reportable(MetricSummary("accuracy", .95, 0, "2025"))
    assert metric_is_reportable(MetricSummary("accuracy", .95, 100, "2025"))


def test_uncalibrated_score_not_probability():
    assert confidence_label(.92, False) == "92/100 uncalibrated score"
    assert confidence_label(.92, True) == "92% calibrated probability"
