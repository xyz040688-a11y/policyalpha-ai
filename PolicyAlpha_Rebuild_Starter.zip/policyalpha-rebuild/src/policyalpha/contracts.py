from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class Action(str, Enum):
    BUY = "BUY"
    SELL = "SELL"
    HOLD = "HOLD"
    WATCHLIST = "WATCHLIST"


class ConfidenceType(str, Enum):
    CALIBRATED_PROBABILITY = "calibrated_probability"
    UNCALIBRATED_SCORE = "uncalibrated_score"
    NOT_AVAILABLE = "not_available"


@dataclass(frozen=True)
class PriceRange:
    low: float
    high: float

    def __post_init__(self):
        if self.low < 0 or self.high < self.low:
            raise ValueError("Invalid price range")


@dataclass(frozen=True)
class Forecast:
    forecast_id: str
    instrument_id: str
    action: Action
    created_at: str
    horizon_sessions: int
    reference_price: float
    thesis: str
    model_version: str
    confidence: Optional[float] = None
    confidence_type: ConfidenceType = ConfidenceType.NOT_AVAILABLE
    entry_range: Optional[PriceRange] = None
    target_range: Optional[PriceRange] = None
    risk_range: Optional[PriceRange] = None
    event_ids: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self):
        if self.horizon_sessions <= 0:
            raise ValueError("horizon_sessions must be positive")
        if self.reference_price <= 0:
            raise ValueError("reference_price must be positive")
        if self.confidence is not None and not 0 <= self.confidence <= 1:
            raise ValueError("confidence must be between 0 and 1")
        if self.confidence_type == ConfidenceType.CALIBRATED_PROBABILITY and self.confidence is None:
            raise ValueError("calibrated probability requires a value")
