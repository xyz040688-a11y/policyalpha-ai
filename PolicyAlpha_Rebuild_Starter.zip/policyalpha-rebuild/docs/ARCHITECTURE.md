# PolicyAlpha system architecture

## High-level flow

```text
Portfolio input ─┐
Market data ─────┤
News / policy ───┼─> Ingestion + provenance + point-in-time store
Disclosures ─────┤                         |
Global macro ────┘                         v
                                    Event intelligence
                              (dedupe, timestamp, cause,
                               materiality, pre-event reaction)
                                                |
                                                v
                                  Macro / policy transmission graph
                               (event -> variable -> sector -> company)
                                                |
                                                v
                                Company & sector analysis
                             (exposure, fundamentals, valuation,
                              peer network, expectations, price)
                                                |
                                                v
                                   Decision & scenario engine
                              (BUY / SELL / HOLD / WATCHLIST,
                               entry/exit, target, risk, horizon)
                                                |
                           ┌────────────────────┴────────────────────┐
                           v                                         v
                  Portfolio assessment                      Prediction ledger
             (holdings, goal scenarios,             (immutable forecast, actual,
              score, suggested changes)               benchmark, validation)
                           |                                         |
                           └────────────────────┬────────────────────┘
                                                v
                                  Report / dashboard renderer
                              (one concise dark-mode PDF, <= 5 pages)
```

## Components

### 1. Ingestion and provenance
Read-only adapters. Every datum carries provider, source URL/id, observed time, publication time, retrieval time, currency, units, symbol mapping and quality status. Store raw snapshots separately from normalized records. A headline snippet is not verified full-text evidence.

### 2. Event intelligence
Normalize and deduplicate coverage into event clusters; preserve first publication/update timestamps; distinguish genuinely new information from repeated coverage; estimate materiality; classify cause only when evidence supports it. Compare market/sector/stock movement in a 30-minute pre-event window and post-event windows where intraday data exists. Daily candles cannot prove a 30-minute reaction. Avoid double-counting publishers reporting the same event.

### 3. Transmission graph
Represent event -> macro variable -> industry input/demand -> sector -> company exposure -> financial channel -> stock thesis. Each edge carries direction, lag, evidence, confidence, source and counterarguments. Example: falling steel prices may reduce auto input costs, but a demand-led collapse may weaken vehicle demand too. Correlation alone is not causation.

### 4. Company intelligence
Business model, segment/geographic/customer exposure, input-cost and energy exposure, sourcing, hedging and inventory, order book, capacity, pricing power, balance sheet, cash flow, profitability, governance, peer read-through, sector-aware valuation and market expectations.

### 5. Valuation and price scenarios
Use appropriate methods by business type (cash-flow, earnings, asset-based, sum-of-parts or sector-specific methods). Disclose assumptions. Entry/target/exit ranges derive from valuation, expected fundamentals, event impact, volatility and risk/reward—not arbitrary offsets from current price.

### 6. Decision engine
Combine independent evidence groups with explicit weights, data-quality gates and contradiction handling. Confidence must be calibrated against out-of-sample outcomes. A score is not a probability unless calibration establishes that interpretation.

### 7. Portfolio engine
Map holdings to company/event/sector intelligence, quantify concentration and risk, compare portfolio scenarios with the 30% aspirational objective, and suggest changes only when expected benefit justifies costs and risks. No order execution.

### 8. Prediction ledger and validation
Persist forecast-time features and source references. Resolve outcomes only after horizon maturity. Benchmark against NIFTY 50 and relevant sector indices. Separate historical training/validation from sealed test and prospective live evidence.

### 9. Presentation
One report, maximum five pages, dark fintech visual language, concise cards and charts. Green for positive/profit; red for negative/loss. No repetitive messages or raw-data dumps.

## Runtime modes

- `validate`: offline schema and safety checks.
- `analyse`: explicitly invoked analysis for supplied/current data.
- `evaluate`: explicitly invoked historical evaluation on a fixed, identified dataset.
- `report`: render a report from a completed analysis snapshot.

No daemon, scheduler, recurring training, automatic model update or autonomous trading service is part of the initial design.
