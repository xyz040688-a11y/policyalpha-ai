# PolicyAlpha AI

Institutional-style equity decision-support for Indian and global equities.

PolicyAlpha connects material news, government policy, macro/commodity changes, company exposure, fundamentals, sector-aware valuation, peer networks, market expectations and portfolio context. It produces explainable BUY / SELL / HOLD / WATCHLIST decisions with entry/exit zones, target and downside ranges, horizon, risks and calibrated confidence only where validated.

**Hard boundary:** analysis and decision support only. Never place, authorise, route or execute trades.

## Rebuild status

This is a clean-room architecture scaffold reconstructed from the supplied ChatGPT conversation export. The export contains conversation history, not the old repository source tree or provider credentials. It is therefore not an exact source-code clone, and historic performance claims remain unverified until original prediction records and datasets are available.

## Operating rules

- No continuous learning, scheduled retraining, self-modifying weights or background loops.
- Manual execution only. The included GitHub Actions workflow is `workflow_dispatch` only.
- No broker or order-execution integration.
- Never fabricate prices, news, holdings, confidence or performance.
- Preserve source timestamps and point-in-time snapshots to prevent look-ahead bias.
- No secrets, screenshots or private portfolio data committed to Git.
- Provider integrations require explicit provider selection, cost/rate limits and user-controlled secrets.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -e ".[dev]"
pytest
python -m policyalpha.cli validate
```

The current code validates contracts and safety rules. Live data adapters and production forecasting are intentionally not enabled until providers are selected.

## Documents

- `docs/ARCHITECTURE.md` — system architecture
- `docs/PRODUCT_REQUIREMENTS.md` — requirements reconstructed from the conversation
- `docs/MODEL_VALIDATION.md` — scoring, confidence and evaluation
- `docs/DATA_CONTRACTS.md` — provenance and record formats
- `docs/REPORT_SPEC.md` — five-page dark fintech report
- `docs/SAFETY_AND_OPERATIONS.md` — manual-only and account-protection rules
